def funcao_f(x):
    import math
    
    return x - math.cos(x)


def funcao_f_linha(x):
    import math
    
    return 1 + math.sin(x)


