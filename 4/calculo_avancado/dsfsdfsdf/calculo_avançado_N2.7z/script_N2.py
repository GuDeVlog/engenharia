from metodo_newton_raphson import metodo_newton_raphson

x0 = 1
num_iter = 3
Estimativa_final = metodo_newton_raphson(x0, num_iter)
print(Estimativa_final)